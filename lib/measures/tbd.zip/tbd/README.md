

###### (Automatically generated documentation)

# 

## Description


## Modeler Description


## Measure Type
ModelMeasure

## Taxonomy


## Arguments




This measure does not have any user arguments


